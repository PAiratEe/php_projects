<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Кроссворд</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<h1 align="center">Кроссворд</h1>
<form method="post">
    <center>
    <table>
        <tr>
            <td></td>
            <td class="w"<i>1</i><input type="text" size="3" name="crw12" value=""></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td></td>
            <td class="w"><input type="text" size="3" name="crw22" value=""></td>
            <td></td>
            <td></td>
            <td class="w"><i>3</i><input type="text" size="3" name="crw25" value=""></td>
            <td class="w"><input type="text" size="3" name="crw26" value=""></td>
            <td class="w"><i>2</i><input type="text" size="3" name="crw27" value=""></td>
            <td class="w"><input type="text" size="3" name="crw28" value=""></td>
            <td></td>
        </tr>
        <tr>
            <td class="w"><i>1</i><input type="text" size="3" name="crw31" value=""></td>
            <td class="w"><input type="text" size="3" name="crw32" value=""></td>
            <td class="w"><input type="text" size="3" name="crw33" value=""></td>
            <td class="w"><i>4</i><input type="text" size="3" name="crw34" value=""></td>
            <td></td>
            <td></td>
            <td class="w"><input type="text" size="3" name="crw37" value=""></td>
            <td></td>
            <td class="w"><i>3</i><input type="text" size="3" name="crw39" value=""></td>
        </tr>
        <tr>
            <td></td>
            <td class="w"><i>5</i><input type="text" size="3" name="crw42" value=""></td>
            <td class="w"><input type="text" size="3" name="crw43" value=""></td>
            <td class="w"><input type="text" size="3" name="crw44" value=""></td>
            <td class="w"><input type="text" size="3" name="crw45" value=""></td>
            <td></td>
            <td class="w"><input type="text" size="3" name="crw47" value=""></td>
            <td></td>
            <td class="w"><input type="text" size="3" name="crw48" value=""></td>
        </tr>
        <tr>
            <td></td>
            <td class="w"><input type="text" size="3" name="crw52" value=""></td>
            <td></td>
            <td class="w"><input type="text" size="3" name="crw54" value=""></td>
            <td></td>
            <td></td>
            <td class="w"><input type="text" size="3" name="crw57" value=""></td>
            <td></td>
            <td class="w"><input type="text" size="3" name="crw59" value=""></td>
        </tr>
        <tr>
            <td></td>
            <td class="w"><input type="text" size="3" name="crw62" value=""></td>
            <td></td>
            <td class="w"><input type="text" size="3" name="crw64" value=""></td>
            <td></td>
            <td></td>
            <td class="w"><input type="text" size="3" name="crw67" value=""></td>
            <td></td>
            <td class="w"><input type="text" size="3" name="crw69" value=""></td>
        </tr>
        <tr>
            <td></td>
            <td class="w"><input type="text" size="3" name="crw72" value=""></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td class="w"><input type="text" size="3" name="crw77" value=""></td>
            <td></td>
            <td class="w"><input type="text" size="3" name="crw79" value=""></td>
        </tr>
        <tr>
            <td></td>
            <td class="w"><i>2</i><input type="text" size="3" name="crw82" value=""></td>
            <td class="w"><input type="text" size="3" name="crw83" value=""></td>
            <td class="w"><input type="text" size="3" name="crw84" value=""></td>
            <td class="w"><i>5</i><input type="text" size="3" name="crw85" value=""></td>
            <td class="w"><input type="text" size="3" name="crw86" value=""></td>
            <td class="w"><input type="text" size="3" name="crw87" value=""></td>
            <td class="w"><input type="text" size="3" name="crw88" value=""></td>
            <td class="w"><input type="text" size="3" name="crw89" value=""></td>
        </tr>
        <tr>
            <td></td>
            <td class="w"><input type="text" size="3" name="crw92" value=""></td>
            <td></td>
            <td></td>
            <td class="w"><input type="text" size="3" name="crw95" value=""></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td></td>
            <td class="w"><input type="text" size="3" name="crw102" value=""></td>
            <td></td>
            <td></td>
            <td class="w"><input type="text" size="3" name="crw105" value=""></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td></td>
            <td class="w"><input type="text" size="3" name="crw112" value=""></td>
            <td></td>
            <td class="w"><i>4</i><input type="text" size="3" name="crw114" value=""></td>
            <td class="w"><input type="text" size="3" name="crw115" value=""></td>
            <td class="w"><input type="text" size="3" name="crw116" value=""></td>
            <td class="w"><input type="text" size="3" name="crw117" value=""></td>
            <td class="w"><input type="text" size="3" name="crw118" value=""></td>
            <td class="w"><input type="text" size="3" name="crw119" value=""></td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td class="w"><input type="text" size="3" name="crw125" value=""></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
    </table><br>
    </center>
    <p>По вертикали</p>
    <ol>
        <li>Женщина, которая занимается самогоноварением</li>
        <li>Фрукт</li>
        <li>4-ый месяц в году</li>
        <li>Есть озеро, а есть...</li>
        <li>Средство для записей</li>
    </ol>
    <p>По горизонтали</p>
    <ol>
        <li>... Хайям</li>
        <li>Антоним скупости</li>
        <li>Кисловатый напиток, приготовляемый на воде из хлеба с солодом</li>
        <li>Род деревьев и кустарников семейства бобовых</li>
        <li>Существа вымышленной расы, придуманный Толкином, извращённые Морготом эльфы</li>
    </ol><br>
    <center>
    <input class="check" type="submit" value="Проверить">
    </center>
</form><br>
<?php
    $vAnswer = array(
        array("самогонщица", 12, 22, 32, 42, 52, 62, 72, 82, 92, 102, 112),
        array("абрикос", 27, 37, 47, 57, 67, 77, 87),
        array("апрель", 39, 49, 59, 69, 79, 89),
        array("река", 34, 44, 54, 64),
        array("ручка", 85, 95, 105, 115, 125),
    );
    $hAnswer = array(
        array("омар", 31, 32, 33, 34),
        array("щедрость", 82, 83, 84, 85, 86, 87, 88, 89),
        array("квас", 25, 26, 27, 28),
        array("акация", 114, 115, 116, 117, 118, 119),
        array("орки", 42, 43, 44, 45),
    );
    print "<p>Ответы по вертикали</p>";
    for ($i = 0; $i < 5; $i++) {
        $a = "";
        for ($j = 1; $j < count($vAnswer[$i]); $j++) {
            if (!empty($_POST["crw".$vAnswer[$i][$j]])) {
                $a .= $_POST["crw".$vAnswer[$i][$j]];
            }
        }
        if ($vAnswer[$i][0] == $a) {
            print "<p>".($i + 1).") Правильно!</p>";
        }
    }
    print "<p>Ответы по горизонтали</p>";
    for ($i = 0; $i < 5; $i++) {
        $a = "";
        for ($j = 1; $j < count($hAnswer[$i]); $j++) {
            if (!empty($_POST["crw".$hAnswer[$i][$j]])) {
                $a .= $_POST["crw".$hAnswer[$i][$j]];
            }
        }
        if ($hAnswer[$i][0] == $a) {
            print "<p>".($i + 1).") Правильно!</p>";
        }
    }
?>
</body>
</html>

